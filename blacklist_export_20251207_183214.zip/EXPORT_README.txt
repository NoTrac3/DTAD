BLACKLIST SYSTEM DATA EXPORT
========================================

Export Information:
------------------
- Export Type: ALL
- Generated: 2025-12-07 18:32:14 UTC
- Total Files: 9
- Approximate Size: 29.00 MB
- Schema Version: 4

File Structure:
--------------
The export is organized into the following folders:

1. user_ids/ - Blacklisted User ID data
   - CSV: Full data with metadata
   - TXT: Clean list (IDs only)
   - JSON: Structured data format

2. usernames/ - Blacklisted username data
   - CSV: Full data with metadata  
   - TXT: Clean list (usernames only)
   - JSON: Structured data format

3. threat_logs/ - Threat detection history
   - CSV: Complete threat log data
   - JSON: Structured threat data

4. statistics/ - System analytics
   - JSON: Network statistics
   - TXT: Database summary

5. database_backup/ - Full database backup
   - DB: Complete SQLite database file

Usage Notes:
-----------
- Clean TXT files are ideal for quick reviews or imports
- CSV files contain full metadata for analysis
- JSON files provide structured data for applications
- The database backup can be restored using SQLite tools

Importing Data:
--------------
- Use the clean TXT files for bulk imports
- CSV files can be used for data migration
- JSON files work with the import_blacklist command

Security Notice:
---------------
This data contains sensitive information. Please:
- Store securely
- Share only with authorized personnel
- Delete when no longer needed

For support or questions, contact the system administrators.
